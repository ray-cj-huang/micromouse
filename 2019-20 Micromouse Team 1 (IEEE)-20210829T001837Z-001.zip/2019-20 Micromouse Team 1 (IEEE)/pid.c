/*
 * pid.c
 *
 *  Created on: Oct 26, 2019
 *      Author: Caleb Terrill
 */

#include "main.h"
#include "encoders.h"
#include "motors.h"

void PID_Reset(void)
{
	/*Reset your motors, encoders, and all the variables in this .c file.*/
	Motors_Reset();
	Encoders_Reset();
}

/*Should be called every millisecond to update your motor PWM duty cycles*/
void PID_Update(void)
{
	/*This is the meat of your PID.
	 * Here you should be reading from your encoders, finding your error,
	 * calculating PWM duty cycles for your distance and angle correction,
	 * and setting motor PWMs. */
	static int count = 0

	const int BASE_PWM = 0.4;
	int goalAngle = 0;
	int dt = 0.001;

	int right = GetEncoderRCounts();
	int left = GetEncoderLCounts();

	int angle = right - left;
	static int oldError = 0;
	int angleError = goalAngle - angle;

	int Kp = 0.5;
	int Kd = 0.5;

	int pwmFixed[11];

	pwmFixed[count%11] = Kp*angleError + Kd*(angleError-oldError)*dt;

	//setting pwm
	if (count >= 10)
	{
		int correction = pwmFixed[(count+1)%11] +

	} else
	{
		int correction = pwmFixed[0];
	}

	MotorR_PWM_Set(BASE_PWM + correction);
	MotorL_PWM_Set(BASE_PWM - correction);

	//set for next iteration
	oldError = angleError;
	count++;

	/* If you are sufficiently close to the goal, you should keep track of how long you
	 * have been in a sufficiently close state. This will be helpful for the PID_Done function.
	 * Perhaps you will only return that the PID is done if you have been sufficiently close for 50 straight
	 * calls of this function... or something like that. */
	int close = 0;
	if (correction < 0.01)
	{
		close++;
	}

	if (close > 50)
		return;
}

void PID_Set_GoalD(int32_t d)
{
	/*Set your PID goal distance.*/
}
void PID_Set_GoalA(int32_t a)
{
	/*Set your PID goal angle.*/
}

/*Can be used by your controller to know when the PID is sufficiently close to the goal state.*/
int8_t PID_Done(void)
{
	/*Recommended: return 1 if the PID is sufficiently close to the goal for a long enough amount of time, else return 0.*/
}
