/*
 * controller.h
 *
 *  Created on: Oct 26, 2019
 *      Author: Caleb Terrill
 */

#ifndef CONTROLLER_H_
#define CONTROLLER_H_

#include "main.h"

void Move_Cells(int8_t n);
void Turn(int8_t n);

#endif /* CONTROLLER_H_ */
