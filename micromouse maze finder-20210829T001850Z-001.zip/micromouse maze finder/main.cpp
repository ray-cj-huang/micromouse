#include <iostream>
#include <cstdlib>  // atoi
#include <stack>

#include "Maze.h"
#include "MazeDefinitions.h"
#include "PathFinder.h"

/**
 * Demo of a PathFinder implementation.
 *
 * Do not use a left/right wall following algorithm, as most
 * Micromouse mazes are designed for such algorithms to fail.
 */
 //class Coord
 //{
 //public:
 //    Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
 //    int r() const { return m_r; }
 //    int c() const { return m_c; }
 //private:
 //    int m_r;
 //    int m_c;
 //};

class LeftWallFollower : public PathFinder {
public:
    LeftWallFollower(bool shouldPause = false) : pause(shouldPause) {
        visitedStart = false;
        dir = 0; //0 = north, 1 = east, 2 = south, 3 = west
        for (int r = 0; r < 16; ++r)
        {
            for (int c = 0; c < 16; ++c)
            {
                manhDist[r][c] = 0;
                if (r <= 7)
                    manhDist[r][c] += 7 - r;
                else
                    manhDist[r][c] += r - 8;
                if (c <= 7)
                    manhDist[r][c] += 7 - c;
                else
                    manhDist[r][c] += c - 8;
            }
        }
        for (int i = 0; i < 16; ++i)
        {
            vertWall[0][i] = true;
            vertWall[16][i] = true;
            horiWall[i][0] = true;
            horiWall[i][16] = true;
        }
    }

    MouseMovement nextMovement(unsigned x, unsigned y, const Maze& maze) {
        // Pause at each cell if the user requests it.
        // It allows for better viewing on command line.
        if (pause) {
            std::cout << "Hit enter to continue..." << std::endl;
            std::cin.ignore(10000, '\n');
            std::cin.clear();
        }

        std::cout << maze.draw(5) << std::endl << std::endl;

        // If we somehow miraculously hit the center
        // of the maze, just terminate and celebrate!
        if (isAtCenter(x, y)) {
            std::cout << "Found center! Good enough for the demo, won't try to get back." << std::endl;
            return Finish;
        }
        if (x == 0 && y == 0) {
            if (visitedStart) {
                std::cout << "Unable to find center, giving up." << std::endl;
                return Finish;
            }
            else {
                visitedStart = true;
            }
        }

        //update walls
        bool isWall[4] = { false };
        for (int i = 0; i < 4; i++)
        {
            if (maze.wallInFront())
                isWall[dir] = true;
            if (maze.wallOnLeft())
                isWall[(dir + 3) % 4] = true;
            if (maze.wallOnRight())
                isWall[(dir + 1) % 4] = true;
        }

        if (isWall[0])
            horiWall[x][y + 1] = true;
        if (isWall[1])
            vertWall[x + 1][y] = true;
        if (isWall[2])
            horiWall[x][y] = true;
        if (isWall[3])
            vertWall[x][y] = true;

        //for (int i = 0; i < 16; ++i)
        //{
        //    for (int k = 0; k < 16; ++k)
        //        std::cout << manhDist[i][k] << " ";
        //    std::cout << std::endl;
        //}

        //assume wall works
        /*
        std::cout << "Horiz Wall" << std::endl;
        for (int i = 0; i < 16; ++i)
        {
            for (int k = 0; k < 17; ++k)
                std::cout << horiWall[i][k] << " ";
            std::cout << std::endl;
        }

        std::cout << "Vert Wall" << std::endl;
        for (int i = 0; i < 17; ++i)
        {
            for (int k = 0; k < 16; ++k)
                std::cout << vertWall[i][k] << " ";
            std::cout << std::endl;
        }
        */

        if (!isWall[0] && (manhDist[x][y + 1] < manhDist[x][y]))
            return move(0);
        if (!isWall[1] && (manhDist[x + 1][y] < manhDist[x][y]))
            return move(1);
        if (!isWall[2] && (manhDist[x][y - 1] < manhDist[x][y]))
            return move(2);
        if (!isWall[3] && (manhDist[x - 1][y] < manhDist[x][y]))
            return move(3);


        //update manhDist
        std::stack<Coord> update;
        Coord current(x, y);
        update.push(current);
        while (!update.empty())
        {
            Coord temp = update.top();
            update.pop();
            if (manhDist[temp.r][temp.c] == 0)
                continue; //skip if it reaches the end goal
            int min_manhDist = 999;
            bool isTempWall[4] = { false };

            if (!horiWall[temp.r][temp.c + 1] && manhDist[temp.r][temp.c + 1] < min_manhDist)
            {
                min_manhDist = manhDist[temp.r][temp.c + 1];
            }
            if (!vertWall[temp.r + 1][y] && manhDist[temp.r + 1][y] < min_manhDist)
            {
                min_manhDist = manhDist[temp.r + 1][temp.c];
            }
            if (!horiWall[temp.r][temp.c] && manhDist[temp.r][temp.c - 1] < min_manhDist)
            {
                min_manhDist = manhDist[temp.r][temp.c - 1];
            }

            if (!vertWall[temp.r][temp.c] && manhDist[temp.r - 1][temp.c] < min_manhDist)
            {
                min_manhDist = manhDist[temp.r - 1][temp.c];
            }


            if (min_manhDist == 999)
            {
                std::cout << "Calculating Manh Dist Error" << std::endl;
                return Finish; //error
            }


            if (manhDist[temp.r][temp.c] > min_manhDist)
            {
                continue;
            }

            if (manhDist[temp.r][temp.c] <= min_manhDist)
            {
                manhDist[temp.r][temp.c] = min_manhDist + 1;

                //checking
                for (int i = -2; i < 3; ++i)
                {
                    for (int k = -2; k < 3; ++k)
                        std::cout << manhDist[temp.r + i][temp.c + k] << " ";
                    std::cout << std::endl;
                }

                Coord north(temp.r, temp.c + 1);
                Coord east(temp.r + 1, temp.c);
                Coord south(temp.r, temp.c - 1);
                Coord west(temp.r - 1, temp.c);
                update.push(north);
                update.push(east);
                update.push(south);
                update.push(west);
            }


        }

        return Wait;

        // If we get stuck somehow, just terminate.
        std::cout << "Got stuck..." << std::endl;
        return Finish;
    }

protected:
    int dir;

    int manhDist[16][16];
    bool vertWall[17][16] = { false };
    bool horiWall[16][17] = { false };

    // Helps us determine if we've made a loop around the maze without finding the center.
    bool visitedStart;

    // Indicates we should pause before moving to next cell.
    // Useful for command line usage.
    const bool pause;

    bool isAtCenter(unsigned x, unsigned y) const {
        unsigned midpoint = MazeDefinitions::MAZE_LEN / 2;

        if (MazeDefinitions::MAZE_LEN % 2 != 0) {
            return x == midpoint && y == midpoint;
        }

        return  (x == midpoint && y == midpoint) ||
            (x == midpoint - 1 && y == midpoint) ||
            (x == midpoint && y == midpoint - 1) ||
            (x == midpoint - 1 && y == midpoint - 1);
    }
private:
    MouseMovement move(int i)
    {
        std::cout << "int i: " << i << " dir: " << dir << std::endl;
        if (i == dir)
            return MoveForward;
        if ((i - dir) == -1 || (i - dir) == 3)
        {
            --dir;
            if (dir < 0)
                dir = 3;
            return TurnCounterClockwise;
        }
        ++dir;
        if (dir > 3)
            dir = 0;
        return TurnClockwise;
    }
    struct Coord
    {
        Coord(int x, int y) { r = x; c = y; }
        int r;
        int c;
    };
};

int main(int argc, char* argv[]) {
    MazeDefinitions::MazeEncodingName mazeName = MazeDefinitions::MAZE_CAMM_2012;
    bool pause = true;

    // Since Windows does not support getopt directly, we will
    // have to parse the command line arguments ourselves.

    // Skip the program name, start with argument index 1
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-m") == 0 && i + 1 < argc) {
            int mazeOption = atoi(argv[++i]);
            if (mazeOption < MazeDefinitions::MAZE_NAME_MAX && mazeOption > 0) {
                mazeName = (MazeDefinitions::MazeEncodingName)mazeOption;
            }
        }
        else if (strcmp(argv[i], "-p") == 0) {
            pause = true;
        }
        else {
            std::cout << "Usage: " << argv[0] << " [-m N] [-p]" << std::endl;
            std::cout << "\t-m N will load the maze corresponding to N, or 0 if invalid N or missing option" << std::endl;
            std::cout << "\t-p will wait for a newline in between cell traversals" << std::endl;
            return -1;
        }
    }

    LeftWallFollower leftWallFollower(pause);
    Maze maze(mazeName, &leftWallFollower);
    std::cout << maze.draw(5) << std::endl << std::endl;

    maze.start();
}
